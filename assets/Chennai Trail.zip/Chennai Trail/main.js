var owl = $(".owl-carousel");
owl.owlCarousel({
  loop: true,
  nav: true,
  autoplay: true,
  autoplayTimeout: 2000,
  autoplayHoverPause: true,
  margin: 70,
  responsive: {
    0: {
      items: 1,
    },
    600: {
      items: 2,
    },
    960: {
      items: 4,
    },
    1200: {
      items: 5,
    },
  },
});
